=== Plugin Name ===
Contributors: Migrate Joomla Users
Donate link: http://donatenow.wc.lt/?donate=ram.solanki2005@gmail.com&item-name=Migrate joomla users plugin&method=PayPal
Tags:Joomla Users, WordPress Users
Requires at least: 3.0.1

Migrate users from a Joomla database into WordPress database.

== Description ==

Migrate Joomla Users is a plugin for migrate users from a joomla database into wordPress database.
Migrates authors and other users with their passwords.


== Installation ==

1. Upload the `joomla-users-to-wp-users` folder to the `/wp-content/plugins/` directory.
1. Activate the plugin through the 'Plugins' menu in WordPress.
1. Go to the Migrate Joomla Users.
1. Set Host, Username and Password of joomla database same as wordpress database.
1. Delete users of wordPress site excluding admin user.
1. To remove duplication of users ID in users table, please make unique ID of admin user ID in user table and user meta table which are not exists in joomla users IDs.


== Changelog ==

1.0 - Initial relese
